<?php $__env->startSection('content'); ?>
<div class="box">
        <div class="box-in-box">
                <?php if(isset($alert)): ?>
                    <h3 style="position:absolute; top:70px;"><?php echo e($alert); ?></h3>
                <?php endif; ?>
            <!-- đăng nhập -->
            <form action="<?php echo e(route('dangnhap')); ?>" id="formlogin" method="post">
                <?php echo e(csrf_field()); ?>

                <h2>Login</h2>
                <?php if(count($errors)>0): ?>
                    <div class="alert alert-danger">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($err); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
                <?php if(Session::has('thanhcong')): ?>
                    <div class="alert alert-success"><?php echo e(Session::get('thanhcong')); ?></div>
                <?php endif; ?>
                <div class="inputBox">
                    <input type="text" name="username" required>
                    <label for="">Username</label>
                </div>
                <div class="inputBox">
                    <input type="password" name="password" required>
                    <label for="">Pasword</label>
                </div>
                <button type="submit">Login</button>
                <a class="btn btn-block" id="forgetpass" onclick="changeForgetPass()" >Forget your accout</a>
                <div>
                    <span>Don't have account? </span>
                    <a href="register">Sign Up</a>
                </div>
                <div>
                    <a href="<?php echo e(URL::to('auth/google')); ?>">
                        <i class="fa fa-google"></i>
                        Đăng nhập bằng Google
                    </a>
                </div>
            </form>

            <!-- quên mật khẩu -->
            <form action="<?php echo e(route('setpassword')); ?>" id="formforgetpass" hidden="" method="post">
                <?php echo e(csrf_field()); ?>

                <h2>Forget Password</h2>
                <div class="inputBox">
                    <input type="email" name="email" required>
                    <label for="">Email</label>
                </div>
                <div class="inputBox">
                    <input type="text" name="name" required>
                    <label for="">Name</label>
                </div>
                <div class="inputBox">
                    <input type="text" name="phone" required>
                    <label for="">Phone</label>
                </div>
                <button type="submit">Get Password</button>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('loginBase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelFrameWork\BTLHotel\resources\views/page/login.blade.php ENDPATH**/ ?>