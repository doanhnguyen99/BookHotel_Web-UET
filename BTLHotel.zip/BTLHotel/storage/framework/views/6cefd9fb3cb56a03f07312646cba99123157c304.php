<?php $__env->startSection('content'); ?>
<div class="blog-background" style="height: 576px; background-image: url('source/image/bg_3.jpg');">
        <div class="blog">
            <h1>Blog</h1>
            <a href="#">HOME</a>
            <a href="#">BLOG</a>
        </div>
    </div>
    <div class="container" style="margin-top: 100px;">
        <div class="row">
            <div class="col-lg-8">
                <div class="container" style="margin-bottom: -30px">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="blog-background" style="height: 275px; background-image: url('source/image/blog/image_1.jpg');"></div>
                            <div>
                                <h3 class="heading">Even the all-powerful Pointing has no control about the blind texts</h3>
                            </div>
                            <div class="meta-chart">
                                <div><a href="#">Sep.20, 2018</a></div>
                                <div><a href="#">Admin</a></div>
                                <div><img src="source/image/icons/message.svg" /><a style="margin-left: 5px;" href="#">3</a></div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="blog-background" style="height: 275px; background-image: url('source/image/blog/image_2.jpg');"></div>
                            <div>
                                <h3 class="heading">Even the all-powerful Pointing has no control about the blind texts</h3>
                            </div>
                            <div class="meta-chart">
                                <div><a href="#">Sep.20, 2018</a></div>
                                <div><a href="#">Admin</a></div>
                                <div><img src="source/image/icons/message.svg" /><a style="margin-left: 5px;" href="#">3</a></div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="blog-background" style="height: 275px; background-image: url('source/image/blog/image_3.jpg');"></div>
                            <div>
                                <h3 class="heading">Even the all-powerful Pointing has no control about the blind texts</h3>
                            </div>
                            <div class="meta-chart">
                                <div><a href="#">Sep.20, 2018</a></div>
                                <div><a href="#">Admin</a></div>
                                <div><img src="source/image/icons/message.svg" /><a style="margin-left: 5px;" href="#">3</a></div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="blog-background" style="height: 275px; background-image: url('source/image/blog/image_4.jpg');"></div>
                            <div>
                                <h3 class="heading">Even the all-powerful Pointing has no control about the blind texts</h3>
                            </div>
                            <div class="meta-chart">
                                <div><a href="#">Sep.20, 2018</a></div>
                                <div><a href="#">Admin</a></div>
                                <div><img src="source/image/icons/message.svg" /><a style="margin-left: 5px;" href="#">3</a></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <ul class="pagination">
                        <li>&gt;</li>
                        <li>1</li>
                        <li>2</li>
                        <li>3</li>
                        <li>4</li>
                        <li>5</li>
                        <li>&lt;</li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="container">
                    <form>
                        <input type="text" placeholder="Type a keyword and hit enter" /><img src="source/image/icons/search.svg"></img>
                    </form>
                    <div>
                        <h3>Categories</h3>
                        <ul class="categories">
                            <li>Family<span>1</span></li><hr/>
                            <li>Criminal<span>4</span></li><hr/>
                            <li>Business<span>5</span></li><hr/>
                            <li>Family<span>6</span></li>
                        </ul>
                    </div>
                    <h3 style="margin-bottom: 40px;">Popular artiles</h3>
                    <div class="popular-blog">
                        <div><img class="img-title" src="source/image/blog/image_1.jpg"/></div>
                        <div>
                            <span>Even the all-powerful Pointing has no control about the blind texts<br/></span>
                            <div class="infor-blog">
                                <img src="source/image/icons/calendar.svg" /><a href="#">Oct. 04. 2018</a>
                                <img src="source/image/icons/user.svg" /><a href="#">Dave lewis</a>
                                <img src="source/image/icons/message.svg" /><a href="#">5</a>
                            </div>
                        </div>
                    </div>
                    <div class="popular-blog">
                        <div><img class="img-title" src="source/image/blog/image_2.jpg"/></div>
                        <div>
                            <span>Even the all-powerful Pointing has no control about the blind texts<br/></span>
                            <div class="infor-blog">
                                <img src="source/image/icons/calendar.svg" /><a href="#">Oct. 04. 2018</a>
                                <img src="source/image/icons/user.svg" /><a href="#">Dave lewis</a>
                                <img src="source/image/icons/message.svg" /><a href="#">5</a>
                            </div>
                        </div>
                    </div>
                    <div class="popular-blog">
                        <div><img class="img-title" src="source/image/blog/image_3.jpg"/></div>
                        <div>
                            <span>Even the all-powerful Pointing has no control about the blind texts<br/></span>
                            <div class="infor-blog">
                                <img src="source/image/icons/calendar.svg" /><a href="#">Oct. 04. 2018</a>
                                <img src="source/image/icons/user.svg" /><a href="#">Dave lewis</a>
                                <img src="source/image/icons/message.svg" /><a href="#">5</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelFrameWork\BTLHotel\resources\views/page/blog.blade.php ENDPATH**/ ?>