<?php $__env->startSection('content'); ?>
 <?php
        $path = url('').'/';
    ?>
<div class="blog-background" style="background-image: url('<?php echo e($path); ?>/source/image/bg_3.jpg');">
        <div class="blog">
            <h1>Room</h1>
            <a href="#">HOME</a>
            <a href="#">ROOM</a>
        </div>
    </div>
    <div class="container single-room">
        <div class="row">
            <div class="col-sm-10">
                <h1 class="title-room">PHÒNG GRAND DELUXE</h1>
                <div class="row" style="padding-bottom: 80px;
                                        border-bottom: 3px solid grey;">
                    <div class="col-sm-6">
                        <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
                            <ol class="carousel-indicators">
                                <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
                                <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
                                <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
                            </ol>
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <div class="row item ">
                                        <img src="<?php echo e($single_room['image_room']); ?>" alt="" style="width:100%;">
                                    </div>
                                </div>
                                <div class="carousel-item ">
                                    <div class="row item ">
                                        <img src="<?php echo e($single_room['image_room']); ?>" alt="" style="width:100%;">
                                    </div>
                                </div>
                                <div class="carousel-item ">
                                    <div class="row item ">
                                        <img src="<?php echo e($single_room['image_room']); ?>" alt="" style="width:100%;">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="content-room col-sm-6">
                        <p><?php echo e($single_room['trich_dan']); ?></p>
                        <p>DIỆN TÍCH:<?php echo e($single_room['dien_tich']); ?> mét vuông</p>
                        <?php
                            $quyen_loi = explode(';',$single_room['quyen_loi']);
                        ?>
                        <p>QUYỀN LỢI</p>
                        <ul>
                            <?php $__currentLoopData = $quyen_loi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($element!=""): ?>
                                    
                                    <li><?php echo e($element); ?></li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <div class="price">
                            <p>Giá từ</p><span>$<?php echo e($single_room['price']); ?></span>
                            <a href=""><button type="button" class="btn btn-primary">Đặt phòng ngay</button></a>
                        </div>
                    </div>
                </div>
                <div class="service-room row">
                    <div class="service-room-single col-sm-4">
                        <div class="img-service"><i class="fa fa-tv fa-3x"></i></div>
                        <p class="name-service">TV màn hình phẳng</p>
                    </div>
                    <div class="service-room-single col-sm-4">
                        <div class="img-service"><i class="fa fa-tv fa-3x"></i></div>
                        <p class="name-service">TV màn hình phẳng</p>
                    </div>
                    <div class="service-room-single col-sm-4">
                        <div class="img-service"><i class="fa fa-tv fa-3x"></i></div>
                        <p class="name-service">TV màn hình phẳng</p>
                    </div>
                    <div class="service-room-single col-sm-4">
                        <div class="img-service"><i class="fa fa-shower fa-3x"></i></div>
                        <p class="name-service">TV màn hình phẳng</p>
                    </div>
                    <div class="service-room-single col-sm-4">
                        <div class="img-service"><i class="fa fa-tv fa-3x"></i></div>
                        <p class="name-service">TV màn hình phẳng</p>
                    </div>
                    <div class="service-room-single col-sm-4">
                        <div class="img-service"><i class="fa fa-clock fa-3x "></i></div>
                        <p class="name-service">TV màn hình phẳng</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-2">


                <?php $__currentLoopData = $room_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div style="margin-bottom: 73px;"></div>
                    <div class="room-other" style="margin-bottom: 50px;
                                                   text-align: center;">
                        <h4><?php echo e($value['room_type']); ?></h4>
                        <img src="<?php echo e($value['image_room']); ?>" width="100%">
                        <p><?php echo e($value['trich_dan']); ?></p>
                        <a href="#">Xem thêm &rarr;</a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelFrameWork\BTLHotel\resources\views/page/single-room.blade.php ENDPATH**/ ?>