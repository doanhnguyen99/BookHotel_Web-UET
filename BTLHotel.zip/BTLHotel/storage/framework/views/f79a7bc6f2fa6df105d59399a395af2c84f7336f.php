<?php $__env->startSection('table-option'); ?>
<a href="insert_room_type" class="btn btn-success">Thêm Room Type</a>
<table class="table table-hover">
    <thead>
      <tr>
        <th>Stt</th>
        <th>Room type</th>
        <th>Số phòng trống</th>
        <th>Hình ảnh</th>
        <th>Giá</th>
        <th>Trích dẫn</th>
        <th>Diện tích</th>
        <th>Quyền lợi</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $room_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($value['id_room_type']); ?></td>
        <td><?php echo e($value['room_type']); ?></td>
        <td><?php echo e($value['so_phong_trong']); ?></td>
        <td><?php echo e($value['image_room']); ?></td>
        <td><?php echo e($value['price']); ?></td>
        <td><?php echo e($value['trich_dan']); ?></td>
        <td><?php echo e($value['dien_tich']); ?></td>
        <td><?php echo e($value['quyen_loi']); ?></td>
        
        <td>
          <a href="edit_room_type/<?php echo e($value['id_room_type']); ?>"><i class="fa fa-pencil"></i></a>
          <a href="delete_room_type/<?php echo e($value['id_room_type']); ?>"><i class="fa fa-trash"></i></a>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelFrameWork\BTLHotel\resources\views/admin/show_room_type.blade.php ENDPATH**/ ?>