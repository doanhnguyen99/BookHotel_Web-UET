
    <!-- navbar -->
    <nav style="display: flex;">
        <a href="/index">
            <div class="logo">
                <h4>IslaGrande</h4>
            </div>
        </a>
        <ul class="nav-links">
            <li><a href="<?php echo e($path); ?>index">Home</a></li>
            <li><a href="<?php echo e($path); ?>about">About</a></li>
            <li><a href="<?php echo e($path); ?>blog">Blog</a></li>
            <li><a href="<?php echo e($path); ?>room">Room</a></li>
            <li><a href="<?php echo e($path); ?>user/booking_form">Booking</a></li>

            <li class="li-user">
                <a href="<?php echo e($path); ?>login">admin</a>
                <ul class="ul-user">
                    <li><a href="<?php echo e($path); ?>admin/quanly">Quan ly</a></li>
                </ul>
            </li>
            <li class="li-user">
                <a href="<?php echo e($path); ?>login">user</a>
                <ul class="ul-user">
                    <li><a href="<?php echo e($path); ?>user/profile">Profile user</a></li>
                    <li><a href="<?php echo e($path); ?>user/phong_da_book">Phong da book</a></li>
                </ul>
            </li>
        </ul>
        <div class="burger">
            <div class="line1"></div>
            <div class="line2"></div>
            <div class="line3"></div>
        </div>
    </nav>
  
<?php /**PATH C:\xampp\htdocs\laravelFrameWork\BTLHotel\resources\views/header.blade.php ENDPATH**/ ?>