<?php $__env->startSection('table-option'); ?>
<a href="insert_room" class="btn btn-success">Thêm Room</a>
<table class="table table-hover">
    <thead>
      <tr>
        <th>Số phòng</th>
        <th>Id Room type</th>
        <th>Được thuê</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $room; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($value['room_no']); ?></td>
        <td><?php echo e($value['id_room_type']); ?></td>
        <td><?php
          if ($value['is_rental']) {
            echo 'Đã được thuê';
          }
          else {
             echo 'Chưa được thuê';
            }
        ?>
        </td>
        
        <td>
          <a href="edit_room/<?php echo e($value['room_no']); ?>"><i class="fa fa-pencil"></i></a>
          <a href="delete_room/<?php echo e($value['room_no']); ?>"><i class="fa fa-trash"></i></a>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelFrameWork\BTLHotel\resources\views/admin/show_room.blade.php ENDPATH**/ ?>