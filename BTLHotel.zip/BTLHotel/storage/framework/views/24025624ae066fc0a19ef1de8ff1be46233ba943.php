<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>

<div class="visible-print text-center">
    <h1>Laravel 5.7 - QR Code Generator Example</h1>

    <?php echo $qrCode; ?>

</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravelFrameWork\BTLHotel\resources\views/page/qrCode.blade.php ENDPATH**/ ?>