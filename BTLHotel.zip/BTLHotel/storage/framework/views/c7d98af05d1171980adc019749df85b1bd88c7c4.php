<?php $__env->startSection('table-option'); ?>
<h2>Update Password</h2>
<form action="<?php echo e(route('update_ad_password')); ?>" method="post">
    <?php echo e(csrf_field()); ?>

    <input type="password" name="update_ad_password" value="<?php echo e($password); ?>">
    <button type="submit" class="btn btn-success">Update</button>
</form>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelFrameWork\BTLHotel\resources\views/admin/update_password.blade.php ENDPATH**/ ?>