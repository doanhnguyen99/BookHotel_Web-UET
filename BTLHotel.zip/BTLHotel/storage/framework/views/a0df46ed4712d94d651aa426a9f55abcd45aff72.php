<?php $__env->startSection('title','Phòng đã book'); ?>
<?php $__env->startSection('option'); ?>
<table class="table table-hover">
    <thead>
      <tr>
        <th>Stt</th>
        <th>Id ac</th>
        <th>room_type</th>
        <th>room_no</th>
        <th>so_nguoi</th>
        <th>check_in_date</th>
        <th>check_in_time</th>
        <th>check_out_date</th>
        <th>accepted</th>
        <th>created_at</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $booking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($value['id_bk']); ?></td>
        <td><?php echo e($value['id_ac']); ?></td>
        <td><?php echo e($value['room_type']); ?></td>
        <td><?php echo e($value['room_no']); ?></td>
        <td><?php echo e($value['so_nguoi']); ?></td>
        <td><?php echo e($value['check_in_date']); ?></td>
        <td><?php echo e($value['check_in_time']); ?></td>
        <td><?php echo e($value['check_out_date']); ?></td>
        <td><?php echo e($value['accepted']); ?></td>
        <td><?php echo e($value['created_at']); ?></td>
        
        <td>
          <a href="delete_booked/<?php echo e($value['id_bk']); ?>"><i class="fa fa-trash">Hủy</i></a>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.profileuser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelFrameWork\BTLHotel\resources\views/user/show_booked.blade.php ENDPATH**/ ?>