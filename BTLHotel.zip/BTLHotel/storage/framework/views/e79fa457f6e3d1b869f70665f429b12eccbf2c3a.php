<?php $__env->startSection('table-option'); ?>
<table class="table table-hover">
    <thead>
      <tr>
        <th>Stt</th>
        <th>Name</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Message</th>
        <th>Accept</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $feedback; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($value['id_feedback']); ?></td>
        <td><?php echo e($value['name']); ?></td>
        <td><?php echo e($value['email']); ?></td>
        <td><?php echo e($value['phone']); ?></td>
        <td><?php echo e($value['message']); ?></td>
        
        <td>
          <a href="delete_feedback/<?php echo e($value['id_feedback']); ?>"><i class="fa fa-trash"></i></a>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelFrameWork\BTLHotel\resources\views/admin/show_feedback.blade.php ENDPATH**/ ?>