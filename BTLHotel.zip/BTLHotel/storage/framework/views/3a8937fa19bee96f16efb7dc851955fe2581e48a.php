<?php $__env->startSection('content'); ?>
<div class="box">
        <div class="box-in-box">
            <!-- quên mật khẩu -->
            <form action="setpassword" id="formforgetpass" method="post" onsubmit="return validate()">
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('PUT')); ?>

                <h2>Reset Password</h2>
                <div class="inputBox">
                    <input name="email" value=<?php echo e($email); ?> required>
                    <label for="">Email</label>
                </div>
                <div class="inputBox">
                    <input type="text" name="password" required id="password">
                    <label for="">Password</label>
                </div>
                <div class="inputBox">
                    <input type="text" name="repassword" required id="repassword">
                    <label for="">RePassword</label>
                </div>
                <button type="submit">Get Password</button>
            </form>
        </div>
    </div>
    <script type = "text/javascript">
         function validate()  {
             let u = document.getElementById("password").value;
             let p = document.getElementById("repassword").value;

            if (u!=p){
                alert("password not match");
                return false;
            }

            return true;
         }
      </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('loginBase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelFrameWork\BTLHotel\resources\views/user/setpassword.blade.php ENDPATH**/ ?>