<?php $__env->startSection('table-option'); ?>
    <form method="POST" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <fieldset class="form-group">
            <label for="formGroupExampleInput">Số phòng</label>
            <input type="text" class="form-control" name="room_no" id="room_no" placeholder="Example input">
        </fieldset>
        <fieldset class="form-group">
            <label for="formGroupExampleInput2"></label>
            <select class="form-control" name="id_room_type">
                <option selected value hidden>Thể loại phòng</option>
                <?php $__currentLoopData = $room_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value=<?php echo e($value['id_room_type']); ?>><?php echo e($value['room_type']); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </fieldset>
        <button type="confirm" class="btn btn-success">Thêm mới</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelFrameWork\BTLHotel\resources\views/admin/insert_room.blade.php ENDPATH**/ ?>