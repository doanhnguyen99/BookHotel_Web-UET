<?php $__env->startSection('table-option'); ?>
    <form action="<?php echo e(route('edit_room')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <fieldset class="form-group">
            <label for="formGroupExampleInput">Số phòng</label>
            <input type="text" readonly="readonly" class="form-control" name="room_no" id="room_no" value="<?php echo e($edit_room['room_no']); ?>">
        </fieldset>
        <fieldset class="form-group">
            <label for="formGroupExampleInput2"></label>
            <select class="form-control" name="id_room_type">
                <option selected value hidden>Thể loại phòng</option>
                <?php $__currentLoopData = $room_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php
                    if($edit_room['id_room_type']==$value['id_room_type'])
                    {
                        echo 'selected';
                    }
                ?> value=<?php echo e($value['id_room_type']); ?>><?php echo e($value['room_type']); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </fieldset>
        <fieldset class="form-group">
            <label for="formGroupExampleInput2">Được thuê</label>
            <select class="form-control" name="is_rental">
                <option <?php
                    if($edit_room['is_rental'])
                    {
                        echo 'selected';
                    }
                ?> value=1>Đã được thuê</option>
                <option <?php
                    if(!$edit_room['is_rental'])
                    {
                        echo 'selected';
                    }
                ?> value=0>Chưa được thuê</option>
            </select>
        </fieldset>
        <button type="confirm" class="btn btn-success">Sửa</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelFrameWork\BTLHotel\resources\views/admin/edit_room.blade.php ENDPATH**/ ?>