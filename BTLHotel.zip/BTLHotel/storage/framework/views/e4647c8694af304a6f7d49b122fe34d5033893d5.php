<?php $__env->startSection('content'); ?>
<div class="blog-background" style=" background-image: url('source/image/bg_3.jpg');">
        <div class="blog">
            <h1>Blog</h1>
            <a href="#">HOME</a>
            <a href="#">BLOG</a>
        </div>
    </div>
    <div class="container" style="margin-top: 100px;">
        <div class="row">
            <!-- cột trái -->
            <div class="col-lg-8" style="margin-bottom:30px;">
                <div class="container" style="margin-bottom: -30px" id="showResult">
                    <div class="row" >
                    <!-- hiện kết quả tìm kiếm -->
                    <?php if(isset($search) && sizeof($blog) == 0): ?>
                        <h4>Không có bài viết nào tìm được</h4>
                    <?php endif; ?>
                    <!-- khi có 1 bài viết -->
                    <?php if(sizeof($blog) == 1 && !isset($search)): ?>
                        <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-12">
                                    <h2><?php echo e($value->title); ?></h2>
                                    <b><?php echo e($value->date); ?></b>
                                    <p><?php echo e($value->text1); ?></p>
                                    <img src="<?php echo e($value->image); ?>" alt="image" style="width: 100%;">
                                    <p><?php echo e($value->text2); ?></p>
                                    <b><?php echo e($value->author); ?></b>
                                </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <?php if(sizeof($blog) > 1): ?>
                        <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-6">
                                    <a href="blog?id=<?php echo e($value->id); ?>">
                                        <div class="blog-background" style="
                                        background-image: url(<?php echo e($value->image); ?>);
                                        height: 275px;
                                        background-size: cover;
                                        background-position: center;
                                        position:relative;">
                                            <div class="meta-chart">
                                                <div><?php echo e($value->date); ?></div>
                                                <div><?php echo e($value->author); ?></div>
                                            </div>
                                        </div>
                                    </a>
                                    <a href="blog?id=<?php echo e($value->id); ?>">
                                    <div>
                                        <h3 class="heading"><?php echo e($value->title); ?></h3>
                                    </div>
                                    </a>
                                </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </div>

                    <!-- phân trang -->
                    <div style="height: 77px;text-align: center;">
                        <?php echo $blog->links(); ?>

                    </div>
                </div>
            </div>

            <!-- cột phải -->
            <div class="col-lg-4">
                <div class="container">

                    <!-- search -->
                    <form action="" method="get">
                        <input id="searchblog" name="keyword" type="text" placeholder="Type a keyword and hit enter" required/>
                        <button type="submit">
                            <img src="source/image/icons/search.svg"></img>
                        </button>
                    </form>

                    <!-- random article -->
                    <h3 style="margin-bottom: 40px;">Random artiles</h3>
                    <?php $__currentLoopData = $blogRandom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="popular-blog">
                            <div>
                                <a href="blog?id=<?php echo e($value->id); ?>">
                                    <img class="img-title" src="<?php echo e($value->image); ?>"/>
                                </a>
                            </div>
                            <div>
                                <a href="blog?id=<?php echo e($value->id); ?>">
                                    <span><?php echo e($value->title); ?><br/></span>
                                </a>
                                <div class="infor-blog">
                                    <img src="source/image/icons/calendar.svg" /><?php echo e($value->date); ?>

                                    <img src="source/image/icons/user.svg" /><?php echo e($value->author); ?>

                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelFrameWork\BTLHotel\resources\views/page/blogtest.blade.php ENDPATH**/ ?>