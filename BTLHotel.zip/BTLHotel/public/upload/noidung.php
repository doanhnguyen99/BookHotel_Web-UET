<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Trang web của tôi</title>
	<link rel="stylesheet" type="text/css" href="http://localhost/bai4dulieu/upload/vietns.css">
</head>
<body>
	<div class="before">
			<h1>Chào mừng cô đến với Website của em</h1>
	</div>
	<div class="header">
		<img src="http://localhost/bai4dulieu/upload/avatar.jpg" alt="My avatar" id="myavatar">
		<div class="form" data-href=''>
			<h2>Họ tên:Nguyễn Sỹ Việt</h2>
			<p>
				<b class="label">Tuổi:</b>
				20
			</p>
				<b class="label">Địa chỉ:</b>
				Hà Nội
			<p>
				<b class="label">Trường:</b>
				Đại học công nghệ
			</p>
				<b class="label">Khoa:</b>
				CNTTDHTTNB
			<p>
				<b class="label">MSSV:</b>
				17021128
			</p>
			<p>
				<b class="label">SĐT:</b>
				0368136928
				<?= $num ?>
			</p>
			<p>
				<b class="label">Ước mơ:</b>
				Một túp lều nho nhỏ nằm trên mỏ kim cương
			</p>
		</div>
	</div>
</body>
</html>
