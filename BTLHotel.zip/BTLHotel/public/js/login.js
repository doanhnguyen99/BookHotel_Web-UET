function changeForgetPass(){
    document.getElementById("formlogin").setAttribute('hidden', '')
    document.getElementById("formforgetpass").removeAttribute('hidden');
}
