<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Blog extends Model
{
    //
    protected $table = 'blog';
    public $primaryKey = 'id';
    public $timestamps = false;
}
